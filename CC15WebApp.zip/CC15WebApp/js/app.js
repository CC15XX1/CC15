let info = {
  name: 'CC15',
  version: 0.1,
  creator: 'CC15XX1'
};
var watermark = document.getElementById("watermark");
var creator = document.getElementById("creator");
console.log(info.name + " v" + info.version);

// Dom7
var $ = Dom7;

// Theme
var theme = 'auto';
if (document.location.search.indexOf('theme=') >= 0) {
  theme = document.location.search.split('theme=')[1].split('&')[0];
}

// Init App
var app = new Framework7({
  id: 'me.CC15XX1.CC15',
  root: '#app',
  theme: theme,
  data: function () {
    return {
      user: {
        firstName: 'CC15XX1',
      },
    };
  },
  methods: {
    helloWorld: function () {
      app.dialog.alert('Hello World!');
    },
  },
  routes: routes,
  popup: {
    closeOnEscape: true,
  },
  sheet: {
    closeOnEscape: true,
  },
  popover: {
    closeOnEscape: true,
  },
  actions: {
    closeOnEscape: true,
  },
  vi: {
    placementId: 'pltd4o7ibb9rc653x14',
  },
});