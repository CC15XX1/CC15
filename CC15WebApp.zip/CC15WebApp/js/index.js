let info = {
    name: 'CC15',
    version: 0.1,
    creator: 'CC15XX1'
  };
console.log(info.name + " v" + info.version);